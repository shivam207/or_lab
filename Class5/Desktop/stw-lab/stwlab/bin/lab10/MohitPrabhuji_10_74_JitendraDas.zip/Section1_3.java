package lab10;
import java.util.Scanner;
public class Section1_3 {
	public static void main (String args [ ] )
	{
	String s="misssisipi";
	Scanner input = new Scanner(System.in);
    int a=input.nextInt();
	}
}
