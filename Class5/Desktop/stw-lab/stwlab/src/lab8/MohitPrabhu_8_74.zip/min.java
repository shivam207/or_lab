package lab8;

public class min {

}
